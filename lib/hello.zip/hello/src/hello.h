#ifndef HELLO_H_
#define HELLO_H_
#ifdef __cplusplus
extern "C" {
#endif

char const *make_greeting(char const *);

#ifdef __cplusplus
}
#endif
#endif // HELLO_H_
